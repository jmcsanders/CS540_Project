from flask import Flask, render_template, flash, request
from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField
from wtforms.validators import DataRequired
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from datetime import datetime
from flask_login import UserMixin, login_user, login_manager, login_required, logout_user, current_user



#got to number 3 to add project to git
#Review number 7 to add javascript search to table
#Create a Flask Instance
app = Flask(__name__)

#Update database record


#Add database
#app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///user.db'
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://root:Alice548511@localhost/project'
app.config['SECRET_KEY'] = "mykeys"

#Initialize the database
db = SQLAlchemy(app)


#Create Model
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    email = db.Column(db.String(120), nullable=False, unique=True)
    date_added = db.Column(db.DateTime, default=datetime.utcnow)
    #Create a String
    def __repr__(self):
        return '<Name %r>' % self.name

class Flight(db.Model):
    
    __tablename__ = 'Flight'

    flight_id = db.Column(db.Integer,primary_key=True)
    qrter= db.Column(db.Integer, nullable=False)
    mnth=db.Column(db.Integer, nullable=False)
    day_of_month=db.Column(db.Integer,nullable=False)
    day_of_week=db.Column(db.Integer,nullable=False)
    fl_date=db.Column(db.Date)
    mkt_unique_carrier=db.Column(db.String(15))
    Segment = db.relationship('Segment',backref='Flight',uselist=False)
    Delay = db.relationship('Delay',backref='Flight',uselist=False)
    Cause = db.relationship('Cause',backref='Flight',uselist=False)

def __repr__(self):
    return f"Flight('{self.flight_id}', '{self.qrter}', '{self.mnth}', '{self.day_of_month}', '{self.day_of_week}', '{self.fl_date}', '{self.mkt_unique_carrier}')"

class Segment(db.Model):
    __tablename__ = 'Segment'

    segment_id = db.Column(db.Integer,db.ForeignKey('Flight.flight_id'),primary_key=True)
    origin= db.Column(db.String(55), nullable=False)
    origin_city_name=db.Column(db.String(55), nullable=False)
    origin_state_abr=db.Column(db.String(55), nullable=False)
    dest=db.Column(db.String(55),nullable=False)
    dest_city_name=db.Column(db.String(55),nullable=False)
    dest_state_abr=db.Column(db.String(55),nullable=False)

def __repr__(self):
    return f"Flight('{self.segment_id}', '{self.origin}', '{self.origin_state_abr}', '{self.dest}', '{self.dest_city_name}', '{self.dest_state_abr}')"

    
class Delay(db.Model):
    __tablename__ = 'Delay'

    delay_id = db.Column(db.Integer,db.ForeignKey('Flight.flight_id'),primary_key=True)
    dep_time= db.Column(db.Integer, nullable=False)
    dep_delay=db.Column(db.Integer, nullable=False)
    cancelled=db.Column(db.Integer,nullable=False)

def __repr__(self):
    return f"Flight('{self.delay_id}', '{self.dep_time}', '{self.dep_delay}', '{self.cancelled}')"


class Cause(db.Model):
    __tablename__ = 'Cause'

    cause_id = db.Column(db.Integer,db.ForeignKey('Flight.flight_id'),primary_key=True)
    carrier_delay= db.Column(db.Integer)
    weather_delay=db.Column(db.Integer)
    nas_delay=db.Column(db.Integer)
    security_delay=db.Column(db.Integer)
    late_aircraft_delay=db.Column(db.Integer)

def __repr__(self):
    return f"Flight('{self.cause_id}', '{self.carrier_delay}', '{self.weather_delay}', '{self.nas_delay}', '{self.security_delay}', '{self.late_aircraft_delay}')"

#Create a class Form
class NamingForm(FlaskForm):
    name = StringField("Add your Name", validators=[DataRequired()])
    submit = SubmitField("Submit")

class UserForm(FlaskForm):
    name = StringField("Name", validators=[DataRequired()])
    submit = SubmitField("Submit")

class SearchForm(FlaskForm):
    searched = StringField("Searched", validators=[DataRequired()])
    email = StringField("Email", validators=[DataRequired()])
    submit = SubmitField("Submit")

# Create a route decorator
@app.route('/')
def index():
    return render_template("index.html")

@app.route('/user/register', methods=['GET', 'POST'])
def add_user():
    name = None
    form =UserForm()
    if form.validate_on_submit():
        Users = User.query.filter_by(email=form.email.data).first()
        if Users is None:
            users = User(name=form.name.data, email=form.email.data)
            db.session.add(users)
            db.session.commit()
        name = form.name.data
        form.name.data = ''
        form.email.data = ''
        flash("You are successfully registered")
    our_users = User.query.order_by(User.date_added)
    return render_template("add_user.html", form=form, name=name, our_users=our_users)

@app.route('/update/<int:id>', methods=['POST','GET'])
def update(id):
    form = UserForm()
    name_to_update = User.query.get_or_404(id)
    if request.method == "POST":
        name_to_update.name = request.form['name']
        name_to_update.email = request.form['email']
        try:
            db.session.commit()
            flash("User updated Successfully")
            return render_template("update.html", form=form, name_to_update=name_to_update, id = id)
        except:
            flash("Error! Issue detected")
            return render_template("update.html", form=form, name_to_update=name_to_update, id = id)

    else:
        return render_template("update.html", form=form, name_to_update = name_to_update,id = id)

@app.route('/delete/<int:id>')
def delete(id):
    user_to_delete = User.query.get_or_404(id)
    name = None
    form =UserForm()
    try:
        db.session.delete(user_to_delete)
        db.session.commit()
        flash("User Deleted Successfully")

        our_users = User.query.order_by(User.date_added)
        return render_template("add_user.html", form=form, name=name, our_users=our_users)

    except:
        flash("Oops! There was a problem, Try again...")
        return render_template("add_user.html", form=form, name=name, our_users=our_users)

@app.route('/user')
def user():
    return render_template("user.html")

#Invalid URL
@app.errorhandler(404)
def page_not_found(e):
    return render_template("404.html"), 404

@app.errorhandler(500)
def page_not_found(e):
    return render_template("400.html"), 500

@app.route('/name', methods=['GET','POST'])
def name():
    name = None
    form = NamingForm()

    if form.validate_on_submit():
        name = form.name.data
        form.name.data = ''
        flash("Form Submitted Successfully")
    return render_template("name.html", name = name, form = form)

@app.route('/search', methods=["POST"])
def search():
    pass

