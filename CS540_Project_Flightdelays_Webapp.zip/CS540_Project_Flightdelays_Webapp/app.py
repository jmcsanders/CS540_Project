from itertools import groupby
from operator import or_
from turtle import delay
from flask import Flask, render_template, flash, request
from flask_sqlalchemy import SQLAlchemy
from numpy import average
from sqlalchemy import asc
from sqlalchemy.sql import func, or_, and_, asc
from flask_migrate import Migrate
from datetime import datetime
from flask_login import UserMixin, login_user, login_manager, login_required, logout_user, current_user
from forms import NamingForm, UserForm, SearchForm
import json
import pandas
import sys
import csv
import numpy as np
#Review 3 to add project to git
#Review 7 to add javascript search to table
#---------------------------------------------------------------------------------------------------------------------------
#Run the app with those three steps once all requirement.txt were met.Development environment for easily change tracks. 
#---------------------------------------------------------------------------------------------------------------------------
#1.export FLASK_APP=app.py
#2.export FLASK_ENV=development
#3.flask run --host=0.0.0.0 --port=5004 or whatever port
#----------------------------------------------------------------------------------------------------------------------------------------
#Create a Flask Instance
#-----------------------------------------------------------------------------------------------------------------------------
app = Flask(__name__)
#------------------------------------------------------------------------------------------------------------------------------------
#Add database/connect to databases
#-----------------------------------------------------------------------------------------------------------------------------------
#app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///user.db'
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://root:Alice548511@localhost/project'
app.config['SECRET_KEY'] = "mykeys"

#------------------------------------------------------------------------------------------------------------------------------------
#Initialize the database
#-----------------------------------------------------------------------------------------------------------------------------------
db = SQLAlchemy(app)

#-------------------------------------------------------------------------------------------------------------------
##Create classes as db.Models for database design/or connect models with existing tables for querying
#----------------------------------------------------------------------------------------------------------------------
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    email = db.Column(db.String(120), nullable=False, unique=True)
    date_added = db.Column(db.DateTime, default=datetime.utcnow)
    #Create a String
    def __repr__(self):
        return '<Name %r>' % self.name

class Flight(db.Model):
    
    __tablename__ = 'Flight'

    flight_id = db.Column(db.Integer,primary_key=True)
    qrter= db.Column(db.Integer, nullable=False)
    mnth=db.Column(db.Integer, nullable=False)
    day_of_month=db.Column(db.Integer,nullable=False)
    day_of_week=db.Column(db.Integer,nullable=False)
    fl_date=db.Column(db.Date)
    mkt_unique_carrier=db.Column(db.String(15))
    Segment = db.relationship('Segment',backref='Flight',uselist=False)
    Delay = db.relationship('Delay',backref='Flight',uselist=False)
    Cause = db.relationship('Cause',backref='Flight',uselist=False)

def __repr__(self):
    return f"Flight('{self.flight_id}', '{self.qrter}', '{self.mnth}', '{self.day_of_month}', '{self.day_of_week}', '{self.fl_date}', '{self.mkt_unique_carrier}')"

class Segment(db.Model):
    __tablename__ = 'Segment'

    segment_id = db.Column(db.Integer,db.ForeignKey('Flight.flight_id'),primary_key=True)
    origin= db.Column(db.String(55), nullable=False)
    origin_city_name=db.Column(db.String(55), nullable=False)
    origin_state_abr=db.Column(db.String(55), nullable=False)
    dest=db.Column(db.String(55),nullable=False)
    dest_city_name=db.Column(db.String(55),nullable=False)
    dest_state_abr=db.Column(db.String(55),nullable=False)

def __repr__(self):
    return f"Flight('{self.segment_id}', '{self.origin}', '{self.origin_state_abr}', '{self.dest}', '{self.dest_city_name}', '{self.dest_state_abr}')"

    
class Delay(db.Model):
    __tablename__ = 'Delay'

    delay_id = db.Column(db.Integer,db.ForeignKey('Flight.flight_id'),primary_key=True)
    dep_time= db.Column(db.Integer, nullable=False)
    dep_delay=db.Column(db.Integer, nullable=False)
    cancelled=db.Column(db.Integer,nullable=False)

def __repr__(self):
    return f"Flight('{self.delay_id}', '{self.dep_time}', '{self.dep_delay}', '{self.cancelled}')"


class Cause(db.Model):
    __tablename__ = 'Cause'

    cause_id = db.Column(db.Integer,db.ForeignKey('Flight.flight_id'),primary_key=True)
    carrier_delay= db.Column(db.Integer)
    weather_delay=db.Column(db.Integer)
    nas_delay=db.Column(db.Integer)
    security_delay=db.Column(db.Integer)
    late_aircraft_delay=db.Column(db.Integer)
    

def __repr__(self):
    return f"Flight('{self.cause_id}', '{self.carrier_delay}', '{self.weather_delay}', '{self.nas_delay}', '{self.security_delay}', '{self.late_aircraft_delay}')"

#Table Attributes can also be designed in one big table representing the above relations
class Flightdelays(db.Model):
    __tablename__ = 'Flightdelays'

    flight_id = db.Column(db.Integer,primary_key=True)
    qrter= db.Column(db.Integer, nullable=False)
    mnth=db.Column(db.Integer, nullable=False)
    day_of_month=db.Column(db.Integer,nullable=False)
    day_of_week=db.Column(db.Integer,nullable=False)
    fl_date=db.Column(db.Date)
    mkt_unique_carrier=db.Column(db.String(15))
    origin= db.Column(db.String(55), nullable=False)
    origin_city=db.Column(db.String(55), nullable=False)
    origin_state_abr=db.Column(db.String(55), nullable=False)
    dest=db.Column(db.String(55),nullable=False)
    dest_city_name=db.Column(db.String(55),nullable=False)
    dest_state_abr=db.Column(db.String(55),nullable=False)
    dep_time= db.Column(db.Integer, nullable=False)
    dep_delay=db.Column(db.Integer, nullable=False)
    cancelled=db.Column(db.Integer,nullable=False)
    carrier_delay= db.Column(db.Integer)
    weather_delay=db.Column(db.Integer)
    nas_delay=db.Column(db.Integer)
    security_delay=db.Column(db.Integer)
    late_aircraft_delay=db.Column(db.Integer)
##-----------------------------------------------------------------------------------------------------------------------------------
#list of cities extracted in datasets/conversion to lower case to allow easy search(case insensitive)
#---------------------------------------------------------------------------------------------------------------------------------------
cities=["Denver","denver","dallas","Dallas","Washington","Des Moines","Detroit","Panama City","El Paso","Fort Lauderdale","Spokane","Grand Rapids","Greer","Hayden","Honolulu","Houston","Harlingen/San Benito","Wichita","Indianapolis","Islip","Hilo","Jacksonville","Kona, HI","Las Vegas","Los Angeles","Lubbock","New York","Long Beach","Lihue","Little Rock","Midland/Odessa","Kansas City","Orlando","Chicago","Memphis","Manchester","Miami","Milwaukee","Minneapolis","New Orleans","Montrose/Delta"
"Oakland","Kahului","Oklahoma City","Omaha","Ontario","Norfolk","West Palm Beach/Palm Beach","Portland","Philadelphia","Phoenix","Pittsburgh","Pensacola","Palm Springs","Providence","Portland","Raleigh/Durham","Richmond","Reno","Rochester","Fort Myers","San Diego","San Antonio","Louisville","Seattle","San Francisco","San Jose","San Juan","Salt Lake City","Sacramento","Santa Ana","St. Louis","Tampa","Tulsa","Tucson","Albuquerque","Albany","Amarillo","Atlanta","Austin","Hartford",
"Birmingham","Nashville","Boise","Boston","Buffalo","Burbank","Baltimore","Charleston","Cleveland","Charlotte","Columbus","Corpus Christi","Cincinnati","Savannah","Mission/McAllen/Edinburg","Dallas/Fort Worth","Sarasota/Bradenton","Gunnison","Bozeman","Fayetteville""Key West","Burlington","Baton Rouge","Mobile","Syracuse","Valparaiso","Knoxville","Monterey","Santa Rosa","Asheville","Madison","Peoria","Moline","Flagstaff","Wilmington","Rapid City","Santa Barbara","Tallahassee","Lafayette","Bakersfield","Greensboro/High Point","Fresno","Yuma","Sioux Falls","Fargo","Daytona Beach","New Haven",
"Bangor","Hilton Head","Myrtle Beach","Newark","Appleton","Lexington","Columbia","Lincoln","Cedar Rapids/Iowa City","Chattanooga","Green Bay","Traverse City","Roanoke","Duluth","Harrisburg","Charlottesville","Bristol/Johnson City/Kingsport","Valdosta","Allentown/Bethlehem/Easton","Jackson/Vicksburg","Kalamazoo","Jacksonville/Camp Lejeune","Rochester","Gulfport/Biloxi","Gainesville","Dothan","Huntsville","Bismarck/Mandan","Montgomery","Augusta","Evansville","South Bend","Albany","Saginaw/Bay City/Midland","Minot","Dayton","Bloomington/Normal","Springfield","Brunswick","Fayetteville","Charleston/Dunbar","Columbus","Binghamton","Columbus","Alexandria","Lansing","Monroe","Elmira/Corning","Mosinee","Grand Forks","Shreveport","State College","Ithaca/Cortland","Fort Wayne","Charlotte Amalie","Eagle","Christiansted","Colorado Springs","Anchorage","Kalispell","Melbourne","Jackson","Trenton","Billings","Eugene","Sanford","Punta Gorda","St. Petersburg","St. Cloud","Grand Junction","Concord","Bellingham","Provo","Belleville","Laredo","Niagara Falls","Missoula","Medford","Rockford","Newburgh/Poughkeepsie","Clarksburg/Fairmont","Great Falls","Stockton","Springfield","Hagerstown","Plattsburgh","Ashland","Owensboro",
"Portsmouth","Santa Maria","Idaho Falls","Bend/Redmond","Pasco/Kennewick/Richland","Flint","Ogden","Toledo","Grand Island","Hoolehua","Lanai","Dubuque","Killeen","Tyler","Waterloo","San Angelo","Beaumont/Port Arthur","La Crosse","Manhattan/Ft. Riley","College Station/Bryan","Waco","Lake Charles","Stillwater","Garden City","Texarkana","Scranton/Wilkes-Barre","Brownsville","Wichita Falls","Longview","Abilene","Marquette","Lawton/Fort Sill","Sioux City","Fort Smith","San Luis Obispo","Champaign/Urbana","Columbia","Del Rio","Atlantic City","Akron","Latrobe","White Plains","New Bern/Morehead/Beaufort","Erie","Newport News/Williamsburg","Aspen","Santa Fe","Durango","St. George","Roswell","Joplin","Arcata/Eureka","Williston","Casper","Helena","Dickinson","Hancock/Houghton","Cape Girardeau","Moab","Johnstown","Devils Lake","Jamestown","Dodge City","Staunton","Cheyenne","Salina","Kearney","Eau Claire","Sheridan","Meridian","Lewisburg","Scottsbluff","Liberal","Pueblo","North Platte","Muskegon","Paducah","Hattiesburg/Laurel","Prescott","Decatur","Vernal","Pierre","Watertown","Hays","Alamosa","Ogdensburg","Gillette",
"Laramie","Rock Springs","Riverton/Lander","Everett","Redding","Sun Valley/Hailey/Ketchum","Victoria","Hobbs","North Bend/Coos Bay","Cody","Twin Falls","Lewiston","International Falls","Escanaba","Elko","Pocatello","Brainerd","Aberdeen","Alpena","Sault Ste. Marie","Rhinelander","Iron Mountain/Kingsfd","Butte","Pellston","Bemidji","Cedar City","Hibbing","Fairbanks","Salisbury","Florence","Lynchburg","Greenville","Williamsport","Watertown","Deadhorse","Juneau","Yakutat","Nome","Barrow","Kodiak","Cold Bay","Kotzebue","Ketchikan","Wrangell","Petersburg","Bethel","Cordova","Sitka","Adak Island","Nantucket","Yakima","Walla Walla","Pullman","Wenatchee","King Salmon","Dillingham","Guam","Saipan","Presque Isle/Houlton"]
#cityL = [[word.lower() for word in cities]]

airports = ["DAL",
"DCA","DEN","den","Den","DSM","DTW","ECP","ELP","FLL","GEG","GRR","GSP","HDN","HNL","HOU","HRL","IAD","ICT","IND","ISP","ITO","JAX","KOA","LAS","LAX","LBB","LGA","LGB","LIH","LIT","MAF","MCI","MCO","MDW","MEM","MHT","MIA","MKE","MSP","MSY","MTJ","OAK","OGG","OKC","OMA","ONT","ORF","PBI","PDX","PHL","PHX","PIT","PNS","PSP","PVD","PWM","RDU","RIC","RNO","ROC","RSW","SAN","SAT","SDF","SEA","SFO","SJC","SJU","SLC","SMF","SNA","STL","TPA","TUL","TUS","ABQ","ALB","AMA","ATL","AUS","BDL","BHM","BNA","BOI","BOS","BUF","BUR","BWI","CHS","CLE","CLT","CMH","CRP","CVG","SAV","IAH","MFE","DFW","SRQ","GUC","BZN","XNA","EYW","BTV","BTR","MOB","SYR","VPS","TYS","MRY","STS","AVL","MSN","PIA","MLI","FLG","ILM","RAP","SBA","TLH",
"LFT","BFL","GSO","FAT","YUM","FSD","FAR","DAB","ORD","HVN","BGR","HHH","MYR","EWR","ATW","JFK","LEX","CAE","LNK","CID","CHA","GRB","TVC","ROA","DLH","MDT","CHO","TRI","VLD","ABE","JAN","AZO","OAJ","RST","GPT","GNV","DHN","HSV","BIS","MGM","AGS","EVV","SBN","ABY","MBS","MOT","DAY","BMI","SGF","BQK","FAY","CRW","CSG","BGM","GTR","AEX","LAN","MLU","ELM","CWA","GFK","SHV","SCE","ITH","FWA","STT","EGE","STX","COS","ANC","FCA","MLB","JAC","TTN","BIL","EUG","AZA","SFB","LCK","PGD","PIE","STC","GJT","USA","BLI","PVU","BLV","LRD","IAG","MSO","MFR","RFD","SWF","CKB","GTF","SCK","SPI","HGR","PBG","HTS","OWB","PSM","SMX","IDA","RDM","PSC","FNT","OGD","TOL","GRI","MKK","LNY","DBQ","GRK","TYR","ALO","SJT","BPT","LSE","MHK","CLL","ACT","LCH","SWO","GCK","TXK","AVP","BRO","SPS","GGG","ABI","MQT","LAW","SUX","FSM","SBP","CMI","COU","DRT","ACY","CAK","LBE","HPN","EWN","ERI","PHF",
"ASE","SAF","DRO","SGU","ROW","JLN","ACV","XWA","CPR","HLN","DIK","CMX","CGI","CNY","JST","DVL","JMS","DDC","SHD","CYS","SLN","EAR","EAU","SHR","MEI","LWB","BFF","LBL","PUB","LBF","MKG","PAH","PIB","PRC","DEC","VEL","PIR","ATY","HYS","ALS","OGS","GCC","LAR","RKS","RIW","PAE","RDD","SUN","VCT","HOB","OTH","COD","TWF","LWS","INL","ESC","EKO","PIH","BRD","ABR","APN","CIU","RHI","IMT","BTM","PLN","BJI","CDC","HIB","FAI","SBY","FLO","LYH","PGV","IPT","ART","SCC","JNU","YAK","OME","BRW","ADQ","CDB","OTZ","KTN","WRG","PSG","BET","CDV","SIT","ADK","ACK","YKM","ALW","PUW","EAT","AKN","DLG","GUM","SPN","PQI"]
airportL = [[word.lower() for word in airports]]

states = ["TX","tx","VA","va","CO","co","IA","ia","IA","MI","mi","Mi","FL","fl","Fl","WA","wa","Wa","SC","sc","Sc","HI","Hi","hi","KS","ks","Ks","IN","in","In","NY","Ny","NV","CA","AR","MO","IL","TN","NH","WI","MN","LA","OK","NE","OR","PA","AZ","RI","ME","NC","KY","PR","UT","NM","GA","CT","AL","ID","MA","MD","OH","MT","VT","SD","ND","NJ","MS","WV","VI","AK","WY","TT"]
#statesL = [[word.lower() for word in states]]

#Airlines = ["AA","aa","Aa","AS","AS","as","B6","b6","DL","dl","Dl","dL","F9","F9","G4","g4","HA","Ha","ha","NK","Nk","nk","UA","ua","UA","WN","Wn","wN"]
#AirlinesL = [[word.lower() for word in Airlines]]

#--------------------------------------------------------------------------------------------------------
#csv_city = csv.reader(open('cities.csv', "r"), delimiter=",")
#----------------------------------------------------------------------------------------------------------------------
#-------------------------------------------------------------------------------------------------------------------
##app routes
#----------------------------------------------------------------------------------------------------------------------
#Create a route decorator for webapp
@app.route('/')
def index():
    return render_template("index.html")

#Route for registration with HTTP requests(POST, GET). These methods are used to transfer data from client to server in HTTP protocol
@app.route('/user/register', methods=['GET', 'POST'])
def add_user():
    name = None
    form =UserForm()
    if form.validate_on_submit():
        Users = User.query.filter_by(email=form.email.data).first()
        if Users is None:
            users = User(name=form.name.data, email=form.email.data)
            db.session.add(users)
            db.session.commit()
        name = form.name.data
        form.name.data = ''
        form.email.data = ''
        flash("You are successfully registered")
    our_users = User.query.order_by(User.date_added)
    return render_template("add_user.html", form=form, name=name, our_users=our_users)

#Update database record for current registered user
@app.route('/update/<int:id>', methods=['POST','GET'])
def update(id):
    form = UserForm()
    name_to_update = User.query.get_or_404(id)
    if request.method == "POST":
        name_to_update.name = request.form['name']
        name_to_update.email = request.form['email']
        try:
            db.session.commit()
            flash("User updated Successfully")
            return render_template("update.html", form=form, name_to_update=name_to_update, id = id)
        except:
            flash("Error! Issue detected")
            return render_template("update.html", form=form, name_to_update=name_to_update, id = id)
    else:
        return render_template("update.html", form=form, name_to_update = name_to_update,id = id)

#Delete a registered user
@app.route('/delete/<int:id>')
def delete(id):
    user_to_delete = User.query.get_or_404(id)
    name = None
    form =UserForm()
    try:
        db.session.delete(user_to_delete)
        db.session.commit()
        flash("User Deleted Successfully")

        our_users = User.query.order_by(User.date_added)
        return render_template("add_user.html", form=form, name=name, our_users=our_users)
    except:
        flash("Oops! There was a problem, Try again...")
        return render_template("add_user.html", form=form, name=name, our_users=our_users)

@app.route('/user')
def user():
    return render_template("user.html")

#Invalid URL,page not found
@app.errorhandler(404)
def page_not_found(e):
    return render_template("404.html"), 404

@app.errorhandler(500)
def page_not_found(e):
    return render_template("400.html"), 500

# Login form to add name
@app.route('/name', methods=['GET','POST'])
def name():
    name = None
    form = NamingForm()
    if form.validate_on_submit():
        name = form.name.data
        form.name.data = ''
        flash("Form Submitted Successfully")
    return render_template("name.html", name = name, form = form)

@app.route('/chartareas', methods=['GET','POST'])
def chartareas():
    return render_template("chartareas.html")

#Context processor to render the search inside the base.html because of includes/extends to other templates
@app.context_processor
def base():
    form = SearchForm()
    return dict(form=form)

#First search test route
@app.route('/search', methods=['GET', 'POST'])
def search():
    form =SearchForm()
    Flights = Flight.query
    if form.validate_on_submit():
        searched=form.searched.data
        Flights = Flights.filter(Flight.flight_id.like('%' + searched + '%'))
        Flights = Flights.order_by(Flight.fl_date).all()
        return render_template("search.html", form=form, searched=searched, Flights=Flights)

#Second search: submit input,query database based on input and return query result 
@app.route('/citychart', methods=['GET', 'POST'])
def citychart():
    form =SearchForm()
    if form.validate_on_submit():
        searched=form.searched.data
        if searched in []:
            results = Flight.query\
                .join(Delay, Flight.flight_id==Delay.delay_id)\
                .join(Segment, Flight.flight_id==Segment.segment_id)\
                .with_entities(func.avg(Delay.dep_delay))\
                .add_columns(Flight.mkt_unique_carrier)\
                .filter(Flight.mkt_unique_carrier.in_(('AA','AS','B6','DL','F9','G4','NK','UA','WN')))\
                .filter(Delay.dep_delay >0)\
                .filter(Segment.origin_city_name.ilike('%' + searched + '%'))\
                .group_by(Flight.mkt_unique_carrier).all()
            return render_template("citychart.html", form=form, searched=searched, results=results)
        elif searched in []:
            results = Flightdelays.query\
                .with_entities(func.avg(Flightdelays.dep_delay))\
                .add_columns(Flightdelays.mkt_unique_carrier)\
                .filter(Flightdelays.mkt_unique_carrier.in_(('AA','AS','B6','DL','F9','G4','NK','UA','WN')))\
                .filter(Flightdelays.origin_state_abr.like('%' + searched + '%'))\
                .filter(Flightdelays.dep_delay >0)\
                .group_by(Flightdelays.mkt_unique_carrier).all()
            carrier = []
            count = []
            for i in results:
                carrier.append(i[0])
                count.append(i[1])   
            return render_template("citychart.html", form=form, searched=searched, results=results)
        elif searched in ["AA","aa","AS","as","B6", "DL","F9","G4","NK","UA","WN"]:
            results = Flightdelays.query\
                .with_entities(func.avg(Flightdelays.dep_delay))\
                .add_columns(Flightdelays.mkt_unique_carrier)\
                .filter(Flightdelays.mkt_unique_carrier.in_(('AA','AS','B6','DL','F9','G4','NK','UA','WN')))\
                .filter(Flightdelays.origin_state_abr.like('%' + searched + '%'))\
                .filter(Flightdelays.dep_delay >0)\
                .group_by(Flightdelays.mkt_unique_carrier).all()
            return render_template("citychart.html", form=form, searched=searched, results=results)
        else:
            return render_template("invalid_src.html")   
#To display the chance of delay based on last year data
#A small algorithm was used
#Final Chart Route/functions to search input by city, state, airlines, airport
@app.route('/charts', methods=['GET', 'POST'])
def charts():
    form =SearchForm()
    if form.validate_on_submit():
        searched=form.searched.data
        if searched in cities:
            results = Flight.query\
                .join(Delay, Flight.flight_id==Delay.delay_id)\
                .join(Segment, Flight.flight_id==Segment.segment_id)\
                .with_entities(func.avg(Delay.dep_delay))\
                .add_columns(Flight.mkt_unique_carrier)\
                .filter(Flight.mkt_unique_carrier.in_(('AA','AS','B6','DL','F9','G4','HA','NK','UA','WN')))\
                .filter(Delay.dep_delay >0)\
                .filter(Segment.origin_city_name.ilike('%' + searched + '%'))\
                .group_by(Flight.mkt_unique_carrier).all()
            delay = []
            mkt = []
            for dep_delay, mkt_unique_carrier in results:
                delay.append(str(dep_delay))
                mkt.append(mkt_unique_carrier) 
            return render_template("citychart.html", form=form, searched=searched, results=results, delay = json.dumps(delay), mkt=json.dumps(mkt))
        elif searched in ["TX","tx","VA","va","CO","co","IA","ia","IA","MI","mi","Mi","FL","fl","Fl","WA","wa","Wa","SC","sc","Sc","HI","Hi","hi","KS","ks","Ks","IN","in","In","NY","Ny","ny","NV","nv","Nv","CA","ca","Ca","AR","ar","Ar","MO","mo","Mo","IL","Il","il","TN","Tn","tn","NH","Nh","nh","WI","wi","Wi","MN","mn","LA","La","la","OK","Ok","ok","NE","Ne","ne","OR","or","Or","PA","Pa","pa","AZ","Az","az","ri","RI","Ri","ME","me","Me","NC","Nc","nc","KY","Ky","ky","PR","pr","Pr","UT","Ut","ut","NM","nm","GA","ga","Ga","CT","ct","AL","al","Al","ID","id","MA","ma","Ma","MD","Md","md","OH","oh","Oh","MT","Mt","mt","VT","Vt","SD","sd","Sd","ND","nd","Nd","NJ","nj","MS","ms","Ms","WV","Wv","wv","VI","vi","Vi","AK","ak","Ak","WY","wy","TT","tt"]:
            results = Flightdelays.query\
                .with_entities(func.avg(Flightdelays.dep_delay))\
                .add_columns(Flightdelays.mkt_unique_carrier)\
                .filter(Flightdelays.mkt_unique_carrier.in_(('AA','AS','B6','DL','F9','G4','HA','NK','UA','WN')))\
                .filter(Flightdelays.origin_state_abr.like('%' + searched + '%'))\
                .filter(Flightdelays.dep_delay >0)\
                .group_by(Flightdelays.mkt_unique_carrier).all()
            count = []
            carrier = []
            for dep_delay, mkt_unique_carrier in results:
                count.append(str(dep_delay))
                carrier.append(mkt_unique_carrier)   
            return render_template("statechart.html", form=form, searched=searched, count = json.dumps(count), carrier=json.dumps(carrier))
        elif searched in ["AA","aa","Aa","AS","AS","as","B6","b6","DL","dl","Dl","dL","F9","F9","G4","g4","HA","Ha","ha","NK","Nk","nk","UA","ua","UA","WN","Wn","wn"]:
            results = db.session.query(
                (func.sum(Flightdelays.dep_delay)/func.sum(Flightdelays.dep_delay + Flightdelays.cancelled + \
                Flightdelays.carrier_delay + Flightdelays.weather_delay + Flightdelays.security_delay + Flightdelays.late_aircraft_delay)*100),\
                (func.sum(Flightdelays.cancelled)/func.sum(Flightdelays.dep_delay + Flightdelays.cancelled + \
                Flightdelays.carrier_delay + Flightdelays.weather_delay + Flightdelays.security_delay + Flightdelays.late_aircraft_delay)*100),\
                (func.sum(Flightdelays.carrier_delay)/func.sum(Flightdelays.dep_delay + Flightdelays.cancelled + \
                Flightdelays.carrier_delay + Flightdelays.weather_delay + Flightdelays.security_delay + Flightdelays.late_aircraft_delay)*100),\
                (func.sum(Flightdelays.weather_delay)/func.sum(Flightdelays.dep_delay + Flightdelays.cancelled + \
                Flightdelays.carrier_delay + Flightdelays.weather_delay + Flightdelays.security_delay + Flightdelays.late_aircraft_delay)*100),\
                (func.sum(Flightdelays.nas_delay)/func.sum(Flightdelays.dep_delay + Flightdelays.cancelled + \
                Flightdelays.carrier_delay + Flightdelays.weather_delay + Flightdelays.security_delay + Flightdelays.late_aircraft_delay)*100),\
                (func.sum(Flightdelays.security_delay)/func.sum(Flightdelays.dep_delay + Flightdelays.cancelled + \
                Flightdelays.carrier_delay + Flightdelays.weather_delay + Flightdelays.security_delay + Flightdelays.late_aircraft_delay)*100),\
                (func.sum(Flightdelays.late_aircraft_delay)/func.sum(Flightdelays.dep_delay + Flightdelays.cancelled + \
                Flightdelays.carrier_delay + Flightdelays.weather_delay + Flightdelays.security_delay + Flightdelays.late_aircraft_delay)*100))\
                .filter(Flightdelays.mkt_unique_carrier.like('%' + searched + '%'))\
                .group_by(Flightdelays.mkt_unique_carrier).all()
            delays = []
            for i in results:
                delays.append(str(i[0]))
                delays.append(str(i[1]))
                delays.append(str(i[2]))
                delays.append(str(i[3]))
                delays.append(str(i[4]))
                delays.append(str(i[5]))
                delays.append(str(i[6]))
            return render_template("charts.html", form=form, searched=searched, results = json.dumps(delays))
        elif searched in ["DAL","DCA","DEN","den","Den","DSM","DTW","ECP","ELP","FLL","GEG","GRR","GSP","HDN","HNL","HOU","HRL","IAD","ICT","IND","ISP","ITO","JAX","KOA","LAS","LAX","LBB","LGA","LGB","LIH","LIT","MAF","MCI","MCO","MDW","MEM","MHT","MIA","MKE","MSP","MSY","MTJ","OAK","OGG","OKC","OMA","ONT","ORF","PBI","PDX","PHL","PHX","PIT","PNS","PSP","PVD","PWM","RDU","RIC","RNO","ROC","RSW","SAN","SAT","SDF","SEA","SFO","SJC","SJU","SLC","SMF","SNA","STL","TPA","TUL","TUS","ABQ","ALB","AMA","ATL","AUS","BDL","BHM","BNA","BOI","BOS","BUF","BUR","BWI","CHS","CLE","CLT","CMH","CRP","CVG","SAV","IAH","MFE","DFW","SRQ","GUC","BZN","XNA","EYW","BTV","BTR","MOB","SYR","VPS","TYS","MRY","STS","AVL","MSN","PIA","MLI","FLG","ILM","RAP","SBA","TLH","LFT","BFL","GSO","FAT","YUM","FSD","FAR","DAB","ORD","HVN","BGR","HHH","MYR","EWR","ATW","JFK","LEX","CAE","LNK","CID","CHA","GRB","TVC","ROA","DLH","MDT","CHO","TRI","VLD","ABE","JAN","AZO","OAJ","RST","GPT","GNV","DHN","HSV","BIS","MGM","AGS","EVV","SBN","ABY","MBS","MOT","DAY","BMI","SGF","BQK","FAY","CRW","CSG","BGM","GTR","AEX","LAN","MLU","ELM","CWA","GFK","SHV","SCE","ITH","FWA","STT","EGE","STX","COS","ANC","FCA","MLB","JAC","TTN","BIL","EUG","AZA","SFB","LCK","PGD","PIE","STC","GJT","USA","BLI","PVU","BLV","LRD","IAG","MSO","MFR","RFD","SWF","CKB","GTF","SCK","SPI","HGR","PBG","HTS","OWB","PSM","SMX","IDA","RDM","PSC","FNT","OGD","TOL","GRI","MKK","LNY","DBQ","GRK","TYR","ALO","SJT","BPT","LSE","MHK","CLL","ACT","LCH","SWO","GCK","TXK","AVP","BRO","SPS","GGG","ABI","MQT","LAW","SUX","FSM","SBP","CMI","COU","DRT","ACY","CAK","LBE","HPN","EWN","ERI","PHF","ASE","SAF","DRO","SGU","ROW","JLN","ACV","XWA","CPR","HLN","DIK","CMX","CGI","CNY","JST","DVL","JMS","DDC","SHD","CYS","SLN","EAR","EAU","SHR","MEI","LWB","BFF","LBL","PUB","LBF","MKG","PAH","PIB","PRC","DEC","VEL","PIR","ATY","HYS","ALS","OGS","GCC","LAR","RKS","RIW","PAE","RDD","SUN","VCT","HOB","OTH","COD","TWF","LWS","INL","ESC","EKO","PIH","BRD","ABR","APN","CIU","RHI","IMT","BTM","PLN","BJI","CDC","HIB","FAI","SBY","FLO","LYH","PGV","IPT","ART","SCC","JNU","YAK","OME","BRW","ADQ","CDB","OTZ","KTN","WRG","PSG","BET","CDV","SIT","ADK","ACK","YKM","ALW","PUW","EAT","AKN","DLG","GUM","SPN","PQI"]:
            results = Flightdelays.query\
                .with_entities(func.avg(Flightdelays.dep_delay))\
                .add_columns(Flightdelays.day_of_week)\
                .filter(Flightdelays.day_of_week.in_(('1','2','3','4','5','6','7')))\
                .filter(Flightdelays.origin.like('%' + searched + '%'))\
                .filter(Flightdelays.dep_delay >0)\
                .group_by(Flightdelays.day_of_week).all()
            average = []
            day = []
            for dep_delay, day_of_week in results:
                average.append(str(dep_delay))
                day.append(str(day_of_week))
            chance = Flightdelays.query\
                .with_entities(func.count(Flightdelays.dep_delay))\
                .filter(Flightdelays.mkt_unique_carrier.in_(('AA','AS','B6','DL','F9','G4','HA','NK','UA','WN')))\
                .filter(Flightdelays.dep_delay >0)\
                .filter(Flightdelays.origin.like('%' + searched + '%'))\
                .group_by(Flightdelays.mkt_unique_carrier).all()
            result2 = Flightdelays.query\
                .with_entities(func.count(Flightdelays.dep_delay))\
                .filter(Flightdelays.mkt_unique_carrier.in_(('AA','AS','B6','DL','F9','G4','HA','NK','UA','WN')))\
                .filter(Flightdelays.dep_delay == "0")\
                .filter(Flightdelays.origin.like('%' + searched + '%'))\
                .group_by(Flightdelays.mkt_unique_carrier).all()
            predict = Flightdelays.query\
                .with_entities(func.count(Flightdelays.dep_delay))\
                .add_columns(Flightdelays.mkt_unique_carrier)\
                .filter(Flightdelays.origin.like('%' + searched + '%'))\
                .filter(Flightdelays.dep_delay >0)\
                .group_by(Flightdelays.mkt_unique_carrier).all()
            pred = []
            for mkt_unique_carrier in predict:
                pred.append(mkt_unique_carrier)
            chances = []
            for num, nums in zip(chance, result2):
                chances.append((int(num[0]) / (int(nums[0])+int(num[0])) *100))
            chanced = []
            for stuffs in chances:
                chanced.append(str(stuffs)) 
            return render_template("airprt_chart.html", form=form, searched=searched, average = json.dumps(average), day=json.dumps(day), chanced=json.dumps(chanced), pred=json.dumps(pred))
        elif searched in ["All airlines", "all airlines","American Airlines", "american airlines","Alaska Airlines","JetBlue", "Delta Airlines", "Frontier Airlines","Allegiant Air","Hawaiian Airlines","Spirit","United Airlines","Southwest Airlines"]:
            results = Flightdelays.query\
                .with_entities(func.count(Flightdelays.dep_delay))\
                .filter(Flightdelays.mkt_unique_carrier.in_(('AA','AS','B6','DL','F9','G4','HA','NK','UA','WN')))\
                .filter(Flightdelays.dep_delay >0)\
                .group_by(Flightdelays.mkt_unique_carrier).all()
            result2 = Flightdelays.query\
                .with_entities(func.count(Flightdelays.dep_delay))\
                .filter(Flightdelays.mkt_unique_carrier.in_(('AA','AS','B6','DL','F9','G4','HA','NK','UA','WN')))\
                .filter(Flightdelays.dep_delay == "0")\
                .group_by(Flightdelays.mkt_unique_carrier).all()
            result1 = []
            for num, nums in zip(results, result2):
                result1.append((int(num[0]) / (int(nums[0])+int(num[0])) *100))
            result3 = []
            for items in result1:
                result3.append(str(items))
            return render_template("prediction.html", form=form, searched=searched, results=results, result2=result2, result3=json.dumps(result3))
        else:
            return render_template("invalid_src.html")   