from calendar import month
from crypt import methods
import os
from matplotlib.pyplot import title
from flask import Flask, render_template, url_for, request, redirect
from flask_sqlalchemy import SQLAlchemy
app = Flask(__name__)

app.config['SECRET_KEY']= 'GHTR'
app.config['SQLALCHEMY_DATABASE_URI']='sqlite:///flight.db'

db = SQLAlchemy(app)

class Flight(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    qrter= db.column(db.Integer)
    month=db.column(db.Integer)
    day_of_month=db.column(db.Integer)
    day_of_week=db.column(db.Integer)
    fl_date=db.column(db.Date)
    mkt_unique=db.column(db.String(3))
def __repr__(self):
    return f"Flight('{self.id}', '{self.qrter}', '{self.month}', '{self.day_of_month}', '{self.day_of_week}', '{self.fl_date}', '{self.mkt_unique}')"

#Configure db

@app.route('/')
@app.route('/home')
def home():
    return render_template("home2.html")

@app.route('/about')
def about():
    return render_template("about2.html")

@app.route('/contact')
def contact():
    Names = ["Jordan Sanders", "Sean Jennings", "Tyler Martin","Fadjimata Anaroua", "EMBRY-RIDDLE"]
    return render_template("Contact2.html", Names=Names)

@app.route("/result",methods = ['POST', 'GET'])
def result():
    if request.method == 'POST':
        pass   
    else:
        return render_template("search.html")
if __name__ =='__main__':
    app.run(debug= True,port=5001)